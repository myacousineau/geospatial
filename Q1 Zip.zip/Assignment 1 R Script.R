rm(list = ls())


library(sf)
library(tidyverse)

#Read in Data
setwd(
  "C:/Users/micha/OneDrive/Desktop/Master's 2nd Semester/Geospatial/Assignment1"
  )

#Districts
Sys.setenv(SHAPE_RESTORE_SHX = "YES")
border_data <- st_read("ZAF_adm2.shp") %>% 
  mutate(district_id = row_number())

#Dams
unzip("Registered Dams Oct2024.kmz", 
      exdir = "C:/Users/micha/OneDrive/Desktop/Master's 2nd Semester/Geospatial/Assignment1/")

dams <- st_read("doc.kml")

#Rivers
rivers <- st_read("geoclass.shp")
st_crs(rivers) #Missing: set to WGS1984
rivers <- st_set_crs(rivers, 4326)
#https://www.dws.gov.za/iwqs/gis_data/rivslopes/rivprofil.aspx 

#Districts
border_data <- st_set_crs(border_data, 4326)


sf_use_s2(F) #save on computational expense
rivers <- rivers %>%
  select(SLOPE, geometry) %>% #only NB variables 
  mutate(gradient = SLOPE*100) %>%
  select(-SLOPE) %>% 
  rename(geom_rivers=geometry) 


#All of CRS are WGS1984
st_crs(dams)
st_crs(rivers)
st_crs(border_data)
border_data <- st_set_crs(border_data, 4326)

#Checking validity 
valid_dams <- st_is_valid(dams)
any(!valid_dams)

valid_rivers <- st_is_valid(rivers)
any(!valid_rivers)

valid_borders <- st_is_valid(border_data) 
any(!valid_borders) #Some are invalid 

# Fix geometries in border_data and rivers
border_data <- st_make_valid(border_data)
valid_borders <- st_is_valid(border_data) 
any(!valid_borders) #all valid 



#Grouping rivers into districts
rivers_in_districts <- st_intersection(rivers, border_data)


border_with_rivers <- border_data %>%
  st_join(rivers_in_districts, by= district_id)

border_with_rivers <- border_with_rivers %>%
  select(gradient, geometry)


dams <- dams %>%
  st_intersection(border_data)

avg_gradient_by_district <- border_with_rivers %>%
  group_by(geometry) %>%  
  summarize(avg_gradient= mean(gradient))

breaks1 <- c(0, 2.229103, 3.821713, 6.593167, 9.879707, 13.130823, 30)

ggplot() +
  # Districts with gradient shading
  geom_sf(data = avg_gradient_by_district, aes(fill = avg_gradient), color = "grey", size = 0.2) +
  
  # Dam locations as points
  geom_sf(data = dams, color = "black", shape = 19, size = 0.3) +
  
  # Step gradient scale
  scale_fill_stepsn(
    name = "Average District River Gradient",
    colors = c("white", "gray50", "gray40", "gray30", "gray20", "black"), 
  ) +
  
  # Map aesthetics
  theme_minimal() +
  
  # Add caption with Notes wrapped
  labs(
    caption = "\n\nFig. 2. Dam locations and average river gradient by district."
  ) +
  
  # Customize theme for box-like caption
  theme(
    plot.caption = element_text(
      hjust = 0.5,                
      size = 10,                 
      face = "italic",           
      lineheight = 1.2           
    ),
    plot.margin = margin(t = 10, r = 10, b = 70, l = 10),  
    panel.background = element_rect(fill = "white", color = "grey90") 
  )

sf_use_s2(T) 